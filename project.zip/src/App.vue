<template>

    <div class="relative"> 
      <BackgroundImages/>
      <HeaderComp/>
      <!-- body Components -->
      <div class="md:px-[50px] lg:px-40">
        <HeroComp/>
        <SecondPageComp/>
        <StatementComp/>
      </div>

    </div>
  
</template>

<script>
import HeaderComp from '@/components/HeaderComp.vue';
import BackgroundImages from '@/components/BackgroundImages.vue';
import HeroComp from '@/components/HeroComp.vue';
import SecondPageComp from '@/components/SecondPageComp.vue';
import StatementComp from '@/components/StatementComp.vue';

export default {
  name : 'app',
  components : {
    HeaderComp,
    BackgroundImages,
    HeroComp,
    SecondPageComp,
    StatementComp,
  }
}
</script>

<style>

</style>