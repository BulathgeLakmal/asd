<script>

</script>

<template>
  <main>
    <TheWelcome />
  </main>
</template>
