<template>
    <div class="z-0">
        <div class="absolute w-[760px] h-[840px] right-[-100px] rotate-[180deg] top-[70px] opacity-[0.8]">
        <img src="src/img/aa.png" alt="">
    </div>
    </div>
    
</template>

<script>
export default {
    name : "BackgroundImages",

}
</script>
