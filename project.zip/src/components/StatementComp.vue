<template>
    <div class="">
        <!-- grid start statement -->
        <div class="grid-rows-[3fr_1fr] md:grid-rows-[1fr_3fr] ">
            <!-- Ceo Text -->
            <div>
                <h3 class="text-[#293793] text-[16px]">CEO</h3>
                <h1 class="inline bg-[linear-gradient(to_right,rgba(41,55,147,1),rgba(244,131,32,1))] 
                bg-clip-text text-transparent text-[48px] font-bold">Statement</h1>
            </div>

            <!-- statement paragraph -->
            <div class="grid grid-cols-[3fr_1fr] bg-[#F8F9FC] relative">
                <img src="src/img/icons/line vertiacale.png" alt="" class="absolute top-[100px] right-[300px]  ">
                <!-- paragraph text -->
                <div class=" p-11">
                    <div class="p-2 text-[14px]">
                        <p>
                            <b>In the dynamic intersection of finance and technology, many ventures dive in, yet few have the expertise to navigate the complex waters effectively. At BETHEL, we are not just riding the wave of technological advancement; we are at the forefront, shaping the tide itself. We believe in substance over show, in building a platform that stands as a beacon of quality and innovation in the decentralized digital landscape.</b> <br><br>BETHEL is where passion meets expertise, fostering a community where the right individuals converge to craft solutions that are not just timely but timeless. Join us at BETHEL, where we are not just envisioning the future; we are creating it, with integrity, excellence, and a clear vision for a secure and decentralized digital ecosystem.
                        </p>
                    </div>
                </div>

                <!-- photo section  -->
                <div class="grid grid-cols-2  pt-[90px] pb-[40px] "  >
                    <!-- photo -->
                    <img src="src/img/3.png" alt="" class="mt-6 ml-8 scale-[1.1]">

                    <!-- about Photo -->
                    <div class="mt-[58px]">
                        <h2 class="text-[13px] text-[#3E4258]">Craig Bricknell</h2>
                        <h2  class="text-[12] text-[#E9983C]">CEO / Director</h2>
                    </div>
                </div>
                <!-- end of the photo section -->
                
            </div>
            <!-- end of the statement grid -->

        </div>
        <!-- end of the grid -->
    </div>
</template>

<script>
export default {
    name : 'StatementComp.vue',
}
</script>
