<template>
    <!-- nav bar -->
    <nav class="grid md:grid-cols-2 md:px-20 lg:grid-cols-[1fr_3fr_1fr] px-40 z-[50] text-sm font-bold text-[#3E4258] bg-[linear-gradient(to_right,rgba(235,237,250,0.2),rgba(243,246,252,0),rgba(230,233,254,0.2))] py-5">
        <!-- image cols -->
        <div>
            <div class="w-32 p-2"><img src="src/img/bethel-network-logo.png" alt=""></div>
        </div>
        <!-- menu items cols  -->
        <div class="hidden lg:flex items-center justify-start ">
            <!-- menu items  -->
            <div>
                <a href="#" class="m-4">Home</a>
                <a href="#" class="m-4">Platform & Products</a>
                <a href="#" class="m-4">Bethel Token</a>
                <a href="#" class="m-4">Docs</a>
                <a href="#" class="m-4">Contact</a>
            </div>
        </div>

        <!-- register cols -->
        <div class="flex items-center justify-end">
            <div><a href="" class="m-3 font-bold">Sign In</a></div>
            <button class="relative pt-3 pb-3 pr-10 rounded-full border-[solid] border-2 border-[#283B91] shadow-[1px_1px_1px]">
                <a href="" class="m-3 font-extrabold">Sign up</a>
                <!-- arrow icon -->
                <span class="material-symbols-outlined self-baseline absolute right-4">
                    arrow_right_alt
                </span>
            </button>
        </div>

    </nav>
</template>

<script>
export default{
    name : 'HeaderComp',

}

</script>

