<template>
    <div class="grid md:grid-cols-2 lg:grid-cols-4 mt-[128px] z-[300]">
        <!-- block 1 -->
        <div class="grid grid-rows-[3fr_1fr]"> 

            <!-- paragraph -->
            <div>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id nisi laborum, doloremque aut eum sed nihil, praesentium quae labore recusandae possimus dolore soluta, eveniet iste repellendus cupiditate ab est suscipit.</p>
            </div>

            <!-- button grid -->
            <div>
                   <!-- create a button -->
                <div class="grid grid-cols-2 border-2 rounded-lg w-[82px] h-[25px] border-[black] p-[1px] mt-[18px]">
                    <!-- leftside -->
                    <div class="bg-[#173C9F] border-none rounded-lg text-[10px] text-white flex justify-center pt-[2px]">
                        EUR
                    </div>

                    <!-- right side -->
                    <div class="text-[12px] pl-[5px] pt-[1px]">
                        USD
                    </div>
                </div>
            </div>
        </div>

        <!-- block 2 -->
        <div class="flex mt-[50px] justify-center"> 
            <div class="w-[250px] h-[60px] bg-[linear-gradient(to_left,rgba(243,246,252,1),rgba(255,255,255,1))] flex items-center rounded-xl">
                <div class="w-[33px] h-[33px] rounded-full bg-[#E9983C] ml-4"></div>
                <div class="w-[2px] h-[30px] bg-[#E9983C] ml-4"></div>
                <h1 class="text-[16px] ml-5">SMART CONTACT</h1>
            </div>
        </div>

        <!-- block 3 -->
        <div class="flex mt-[50px] justify-center">
            <div class="w-[250px] h-[60px] bg-[linear-gradient(to_left,rgba(243,246,252,1),rgba(255,255,255,1))] flex items-center rounded-xl">
                <img src="src/img/Group.png" alt="" class="scale-125" >
                <div class="w-[2px] h-[30px] bg-[#E9983C] ml-4"></div>
                <h1 class="text-[16px] ml-5">Vetted Projects</h1>
            </div>
        </div>

        <!-- block 4 -->
        <div class="flex mt-[50px] justify-center">
            <div class="w-[250px] h-[60px] bg-[linear-gradient(to_left,rgba(243,246,252,1),rgba(255,255,255,1))] flex items-center rounded-xl">
                <img src="src/img/Group 3.png" alt="" class="" >
                <div class="w-[2px] h-[30px] bg-[#E9983C] ml-4"></div>
                <h1 class="text-[16px] ml-5">TEXT</h1>
            </div>
        </div>

        <!-- block 5 -->
        <div class="mt-[64px] mb-[64px]">
            <div class="grid grid-cols-[1fr_3fr] shadow-[0px_0px_4px_rgba(0,0,0,0.3)] w-[270px] h-[150px] border-none rounded-xl">
                <!-- left side -->
                <div>   
                    <div class="bg-blue-600 w-[50px] h-[50px] rounded-full flex item-center relative m-2">
                        <img src="src/img/icons/Frame.png" alt="" class="absolute top-[10px] left-3">
                    </div>
                </div>

                <!-- right side -->
                <div class="m-2 text-[20px] font-medium">
                    Decentralized File Storage
                </div>
            </div>
        </div>

        <!-- block 6 -->
        <div class="mt-[64px] mb-[64px]">
            <div class="grid grid-cols-[1fr_3fr] shadow-[0px_0px_4px_rgba(0,0,0,0.3)] w-[270px] h-[150px] border-none rounded-xl">
                <!-- left side -->
                <div>   
                    <div class="bg-blue-600 w-[50px] h-[50px] rounded-full flex item-center relative m-2">
                        <img src="src/img/icons/Frame(1).png" alt="" class="absolute top-[10px] left-3">
                    </div>
                </div>

                <!-- right side -->
                <div class="m-2 text-[20px] font-medium">
                    Decentralized Database Storage
                </div>
            </div>
        </div>

        <!-- block 7 -->
        <div class="mt-[64px] mb-[64px]">
            <div class="grid grid-cols-[1fr_3fr] shadow-[0px_0px_4px_rgba(0,0,0,0.3)] w-[270px] h-[150px] border-none rounded-xl">
                <!-- left side -->
                <div>   
                    <div class="bg-blue-600 w-[50px] h-[50px] rounded-full flex item-center relative m-2">
                        <img src="src/img/icons/Frame(2).png" alt="" class="absolute top-[10px] left-3">
                    </div>
                </div>

                <!-- right side -->
                <div class="m-2 text-[20px] font-medium">
                    Decentralized Containers
                </div>
            </div>
        </div>

        <!-- block 8 -->
        <div class="mt-[64px] mb-[64px]">
            <div class="grid grid-cols-[1fr_3fr] shadow-[0px_0px_4px_rgba(0,0,0,0.3)] w-[270px] h-[150px] border-none rounded-xl">
                <!-- left side -->
                <div>   
                    <div class="bg-blue-600 w-[50px] h-[50px] rounded-full flex item-center relative m-2">
                        <img src="src/img/icons/Frame(3).png" alt="" class="absolute top-[10px] left-3">
                    </div>
                </div>

                <!-- right side -->
                <div class="m-2 text-[20px] font-medium">
                    Proof of Distribution
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name : "SecondPageComp"
}
</script>

<style>

</style>