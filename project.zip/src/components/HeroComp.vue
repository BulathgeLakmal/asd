<template> 
    <!--grid hero -->
    <div class="grid grid-cols-1 lg:grid-cols-[1fr_1fr] mt-[24px]">
        <!-- grid 2 -->
        <div class="grid grid-rows-[1fr_2fr_2fr_1fr] mt-12">  
             <!--row 1 bethel Icon container  -->
            <div class="w-[320px] h-[30px] flex items-center px-2 py-2 rounded-full text-[10px] mt-12
            bg-[linear-gradient(to_right,rgba(240,245,254,1),rgba(255,247,236,1))]">

                <img src="src/img/Group.png" alt="" class="w-[16px]">
                <h4 class="m-2">Bethel Token</h4>
                <div class="w-[10px] h-[10px] bg-[#E7E7EB] border-none  rounded-full"></div>
                <h4 class="m-2">Testnet</h4>
                <div class="w-[10px] h-[10px] bg-[#293793] border-none  rounded-full"></div>
                <h4 class="m-2">White Paper</h4>
                <span class="material-symbols-outlined m-2 scale-75">
                    arrow_right_alt
                </span>

            </div>
            <!-- end of the row 1 -->

            <!-- row 2 headline -->
            <div>
                <h1 class="text-[50px] font-bold bg-[linear-gradient(to_right,rgba(41,55,147,1),rgba(244,131,32,1))] 
                bg-clip-text text-transparent leading-[50px] mt-[20px]">All Your digital assests <br> in one secure place</h1>
            </div>

            <!-- row 3 pharagraph -->
            <div>
                <p class="font-medium m-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, architecto molestias. Error similique expedita natus consequatur sed, minus laudantium iusto a iste repudiandae, nam perferendis nobis quaerat recusandae provident at?</p>
            </div>

            <!-- row 4 button -->
            <div>
                <button class="bg-[#293793] w-[182px] h-[51px] text-white rounded-full shadow-[1px_2px_4px_rgba(0,0,0,0.3)]">Join Now</button>
            </div>

        </div>

        <!-- right column -->
        <!-- images side -->
        <div class="relative z-[300] mt-[58px]">
            <img src="src/img/New Project.png" alt="" class="md:scale-75 mt-[1px] lg:scale-125 mt-24">
            <!-- first image -->            
                <!-- <img src="src/img/OD15EW1 copy.png" alt="" class="absolute top-[70px] right-[-50px] z-[200] scale-110">            -->
            <!-- second image -->         
                <!-- <img src="src/img/OD15EW1 22copy.png" alt="" class="absolute right-[20px] top-[220px] z-[300] scale-110">           -->
            <!-- third image -->
                <!-- <img src="src/img/floin-shape-1-alt.png" alt="" class="absolute right-[-10px] top-[280px] z-[300] w-[181px] h-[219px]"> -->
            <!-- bubble image -->
                <!-- <img src="src/img/floin-shape-3-blue.png" alt="" class="absolute left-[-180px] top-[380px] z-[100] scale-50"> -->
        </div>
        <!-- end of the image side -->
    
    </div>
</template>

<script>
export default{
    name : 'HeroComp'
}
</script>
